alias zera="exec bash"
alias carga="source /bin/xtdc"
alias insta="sudo apt-get install $1 -y --no-install-recommends"
alias limpa="sudo apt-get autoremove && sudo apt-get autoclean"

