#!/bin/bash

#######################
#    ^...^  `^...^´   #
#   / o,o \ / O,O \   #
#   |):::(| |):::(|   #
# ====" "=====" "==== #
#         TdC         #
#      1998-2025      #
#######################
# Toca das Corujas
# Códigos Binários,
# Funções de Onda e
# Teoria do Orbital Molecular Inc.
# Unidade Barão Geraldo CX
#

# Função para renomear todos os arquivos para .txt
renomear_para_txt() {
    ls -1 *.desktop 2>/dev/null | while read -r arquivo; do
        [ -f "$arquivo" ] && mv -- "$arquivo" "${arquivo%.*}.txt"
    done
}

# Função 1: Criar arquivo tudo.txt com o nome original e conteúdo
criar_tudo_txt() {
    > tudo.txt  # Limpa o arquivo se existir
    for arquivo in *.txt; do
        if [ "$arquivo" != "tudo.txt" ]; then
            echo "=== ARQUIVO: $arquivo ===" >> tudo.txt
            cat "$arquivo" >> tudo.txt
            echo -e "\n" >> tudo.txt
        fi
    done
}

# Função 2: Recriar arquivos a partir de tudo.txt
recriar_arquivos() {
    local nome_arquivo=""
    local conteudo=""
    
    while IFS= read -r linha; do
        if [[ "$linha" =~ ^===.ARQUIVO:.([^=]+).=== ]]; then
            # Se já temos um arquivo em processamento, salve-o
            if [ -n "$nome_arquivo" ]; then
                echo -n "$conteudo" > "$nome_arquivo"
                conteudo=""
            fi
            nome_arquivo="${BASH_REMATCH[1]}"
        else
            conteudo+="$linha"$'\n'
        fi
    done < tudo.txt
    
    # Salve o último arquivo processado
    if [ -n "$nome_arquivo" ]; then
        echo -n "$conteudo" > "$nome_arquivo"
    fi
}

# Função para renomear todos os .txt para .desktop
renomear_para_desktop() {
    for arquivo in *.txt; do
        if [ "$arquivo" != "tudo.txt" ]; then
            mv "$arquivo" "${arquivo%.*}.desktop"
        fi
    done
    sudo chmod 777 *.desktop

}

# Menu principal
echo "Selecione a opção:"
echo "1 - Renomear arquivos para .txt"
echo "2 - Criar tudo.txt"
echo "3 - Recriar arquivos a partir de tudo.txt"
echo "4 - Renomear arquivos para .desktop"
echo "5 - Executar todas as etapas"
read -p "Opção: " opcao

case $opcao in
    1) renomear_para_txt ;;
    2) criar_tudo_txt ;;
    3) recriar_arquivos ;;
    4) renomear_para_desktop ;;
    5) 
        renomear_para_txt
        criar_tudo_txt
        recriar_arquivos
        renomear_para_desktop
        ;;
    *) echo "Opção inválida" ;;
esac

echo "Operação concluída."
